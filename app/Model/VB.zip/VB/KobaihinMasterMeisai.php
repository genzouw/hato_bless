<?php
class KobaihinMasterMeisai extends AppModel {

    public $useTable = false;
//    public $primaryKey = array('ID','SEIKYU_YM','MOTO_SOSHIKI_CD','SAKI_SOSHIKI_CD','SEIKYU_SIHARAI_CD','HIYOKOMOKU_CD');

    function getKobaihinManageJoho(){

    /*
        Public Shared Function GetKobaihinManageJoho(KobaiName As String, ShiiresakiName As String, KobaiBunruiName As String, HanbaisakiName As String, ByRef MsgCd As String, FindFlg As Integer) As HachuCvs()
            Try
            Catch expr_04 As Exception
                ProjectData.SetProjectError(expr_04)
                Dim ex As Exception = expr_04
                Throw ex
            End Try
            Dim result As HachuCvs()
            Return result
        End Function
     */

    }



}
?>