<?php
class SeisanJuchuKbtList extends AppModel {

    public $useTable = false;
//    public $primaryKey = array('ID','SEIKYU_YM','MOTO_SOSHIKI_CD','SAKI_SOSHIKI_CD','SEIKYU_SIHARAI_CD','HIYOKOMOKU_CD');

    function getUserManageJoho(){

    /*
        Public Shared Function GetUserManageJoho(SecurityName As String, UserId As String, ByRef MsgCd As String, FindFlg As Integer) As UserKanriList()
            Try
            Catch expr_04 As Exception
                ProjectData.SetProjectError(expr_04)
                Dim ex As Exception = expr_04
                Throw ex
            End Try
            Dim result As UserKanriList()
            Return result
        End Function
     */

    }



}
?>